import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _891949b6 = () => interopDefault(import('..\\pages\\android.vue' /* webpackChunkName: "pages/android" */))
const _4b81df12 = () => interopDefault(import('..\\pages\\articles.vue' /* webpackChunkName: "pages/articles" */))
const _615a77fe = () => interopDefault(import('..\\pages\\drivers.vue' /* webpackChunkName: "pages/drivers" */))
const _3cc9adf7 = () => interopDefault(import('..\\pages\\games.vue' /* webpackChunkName: "pages/games" */))
const _0e0ffd42 = () => interopDefault(import('..\\pages\\iphone.vue' /* webpackChunkName: "pages/iphone" */))
const _4267d905 = () => interopDefault(import('..\\pages\\mac.vue' /* webpackChunkName: "pages/mac" */))
const _3b523ac0 = () => interopDefault(import('..\\pages\\mixes.vue' /* webpackChunkName: "pages/mixes" */))
const _cefb6902 = () => interopDefault(import('..\\pages\\phones.vue' /* webpackChunkName: "pages/phones" */))
const _1282c58e = () => interopDefault(import('..\\pages\\windows.vue' /* webpackChunkName: "pages/windows" */))
const _cc4f22c6 = () => interopDefault(import('..\\pages\\download\\process.vue' /* webpackChunkName: "pages/download/process" */))
const _3a10ee83 = () => interopDefault(import('..\\pages\\app\\_slug.vue' /* webpackChunkName: "pages/app/_slug" */))
const _a5a7fcfc = () => interopDefault(import('..\\pages\\category\\_slug.vue' /* webpackChunkName: "pages/category/_slug" */))
const _63f23bb8 = () => interopDefault(import('..\\pages\\download\\_slug.vue' /* webpackChunkName: "pages/download/_slug" */))
const _69731a87 = () => interopDefault(import('..\\pages\\tags\\_slug.vue' /* webpackChunkName: "pages/tags/_slug" */))
const _601f98f0 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/android",
    component: _891949b6,
    name: "android"
  }, {
    path: "/articles",
    component: _4b81df12,
    name: "articles"
  }, {
    path: "/drivers",
    component: _615a77fe,
    name: "drivers"
  }, {
    path: "/games",
    component: _3cc9adf7,
    name: "games"
  }, {
    path: "/iphone",
    component: _0e0ffd42,
    name: "iphone"
  }, {
    path: "/mac",
    component: _4267d905,
    name: "mac"
  }, {
    path: "/mixes",
    component: _3b523ac0,
    name: "mixes"
  }, {
    path: "/phones",
    component: _cefb6902,
    name: "phones"
  }, {
    path: "/windows",
    component: _1282c58e,
    name: "windows"
  }, {
    path: "/download/process",
    component: _cc4f22c6,
    name: "download-process"
  }, {
    path: "/app/:slug?",
    component: _3a10ee83,
    name: "app-slug"
  }, {
    path: "/category/:slug?",
    component: _a5a7fcfc,
    name: "category-slug"
  }, {
    path: "/download/:slug?",
    component: _63f23bb8,
    name: "download-slug"
  }, {
    path: "/tags/:slug?",
    component: _69731a87,
    name: "tags-slug"
  }, {
    path: "/",
    component: _601f98f0,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
