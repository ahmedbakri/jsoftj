import Vue from 'vue'
import { wrapFunctional } from './utils'

const components = {
  Applist: () => import('../..\\components\\Applist.vue' /* webpackChunkName: "components/applist" */).then(c => wrapFunctional(c.default || c)),
  Categories: () => import('../..\\components\\Categories.vue' /* webpackChunkName: "components/categories" */).then(c => wrapFunctional(c.default || c)),
  Comments: () => import('../..\\components\\comments.vue' /* webpackChunkName: "components/comments" */).then(c => wrapFunctional(c.default || c)),
  NuxtLogo: () => import('../..\\components\\NuxtLogo.vue' /* webpackChunkName: "components/nuxt-logo" */).then(c => wrapFunctional(c.default || c)),
  Search: () => import('../..\\components\\search.vue' /* webpackChunkName: "components/search" */).then(c => wrapFunctional(c.default || c)),
  SiteLogo: () => import('../..\\components\\SiteLogo.vue' /* webpackChunkName: "components/site-logo" */).then(c => wrapFunctional(c.default || c)),
  Tutorial: () => import('../..\\components\\Tutorial.vue' /* webpackChunkName: "components/tutorial" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
