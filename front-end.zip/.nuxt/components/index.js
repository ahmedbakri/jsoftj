import { wrapFunctional } from './utils'

export { default as Applist } from '../..\\components\\Applist.vue'
export { default as Categories } from '../..\\components\\Categories.vue'
export { default as Comments } from '../..\\components\\comments.vue'
export { default as NuxtLogo } from '../..\\components\\NuxtLogo.vue'
export { default as Search } from '../..\\components\\search.vue'
export { default as SiteLogo } from '../..\\components\\SiteLogo.vue'
export { default as Tutorial } from '../..\\components\\Tutorial.vue'

export const LazyApplist = import('../..\\components\\Applist.vue' /* webpackChunkName: "components/applist" */).then(c => wrapFunctional(c.default || c))
export const LazyCategories = import('../..\\components\\Categories.vue' /* webpackChunkName: "components/categories" */).then(c => wrapFunctional(c.default || c))
export const LazyComments = import('../..\\components\\comments.vue' /* webpackChunkName: "components/comments" */).then(c => wrapFunctional(c.default || c))
export const LazyNuxtLogo = import('../..\\components\\NuxtLogo.vue' /* webpackChunkName: "components/nuxt-logo" */).then(c => wrapFunctional(c.default || c))
export const LazySearch = import('../..\\components\\search.vue' /* webpackChunkName: "components/search" */).then(c => wrapFunctional(c.default || c))
export const LazySiteLogo = import('../..\\components\\SiteLogo.vue' /* webpackChunkName: "components/site-logo" */).then(c => wrapFunctional(c.default || c))
export const LazyTutorial = import('../..\\components\\Tutorial.vue' /* webpackChunkName: "components/tutorial" */).then(c => wrapFunctional(c.default || c))
