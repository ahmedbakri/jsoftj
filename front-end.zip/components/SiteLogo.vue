<template>
  <img
    class="VuetifyLogo"
    title="جي سوفت"
    alt="جي سوفت"
    src="/logo.png"
  >
</template>

<style>
.VuetifyLogo {
  height: 50px;
}

</style>
